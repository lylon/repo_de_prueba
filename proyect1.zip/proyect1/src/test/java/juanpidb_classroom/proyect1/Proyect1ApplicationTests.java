package juanpidb_classroom.proyect1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Proyect1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
