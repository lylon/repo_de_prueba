package juanpidb_classroom.proyect1;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Proyect1Application {

	public static void main(String[] args) {
		SpringApplication.run(Proyect1Application.class, args);
	}

}
